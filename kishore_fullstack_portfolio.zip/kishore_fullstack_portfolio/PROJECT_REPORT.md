# Full-Stack Personal Portfolio Website

## 1. Aim
To develop a full-stack personal portfolio website that showcases personal information, skills, projects and contact details using frontend, backend and database integration.

## 2. Objective
The objective of this project is to gain practical experience in integrating a frontend website with backend APIs and a database. The website allows users to view portfolio details and send contact messages. The admin can add and delete project details.

## 3. Software Requirements
- HTML
- CSS
- JavaScript
- Node.js
- Express.js
- MongoDB
- Mongoose
- Visual Studio Code

## 4. Hardware Requirements
- Computer or Laptop
- Minimum 4GB RAM
- Internet connection for deployment

## 5. Modules

### User Module
The user can view the portfolio, skills, projects and send messages using the contact form.

### Project Module
Project details are stored in the database and displayed dynamically on the portfolio page.

### Admin Module
Admin can add new projects, delete old projects and view contact messages.

### Contact Module
The contact form stores visitor messages in the MongoDB database.

## 6. System Architecture
Frontend pages communicate with the backend server using API requests. The backend server processes the request and stores or retrieves data from MongoDB.

```txt
User Browser
    ↓
Frontend HTML/CSS/JS
    ↓
Express.js Backend API
    ↓
MongoDB Database
```

## 7. Database Collections

### Project Collection
Stores project title, description, tech stack, GitHub link and live demo link.

### Message Collection
Stores visitor name, email and message.

## 8. Result
The full-stack personal portfolio website was successfully developed with frontend, backend and database integration.

## 9. Conclusion
This project helped in understanding how a real-world full-stack web application works. It provides experience in creating APIs, connecting databases, handling forms and deploying a live website.
