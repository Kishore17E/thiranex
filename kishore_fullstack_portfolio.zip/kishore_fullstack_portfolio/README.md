# Personal Portfolio Website

## Project Title
Full-Stack Personal Portfolio Website

## Student Name
E Kishore

## Project Description
This is a full-stack personal portfolio website created to showcase personal details, skills, projects, resume information and contact details. The project includes frontend pages, backend APIs, MongoDB database integration, project management through an admin panel and a contact form.

## Technologies Used

### Frontend
- HTML
- CSS
- JavaScript

### Backend
- Node.js
- Express.js

### Database
- MongoDB
- Mongoose

### Deployment
- Render / Vercel / Netlify

## Features
- Modern responsive portfolio design
- About section
- Skills section
- Dynamic projects section
- Backend API for storing projects
- Contact form with database storage
- Admin panel to add and delete projects
- Admin panel to view contact messages

## Folder Structure
```txt
kishore-fullstack-portfolio/
│
├── server.js
├── package.json
├── .env.example
├── README.md
│
├── models/
│   ├── Project.js
│   └── Message.js
│
└── public/
    ├── index.html
    ├── admin.html
    ├── style.css
    ├── script.js
    └── admin.js
```

## How to Run This Project

### Step 1: Install Node.js
Download and install Node.js from the official website.

### Step 2: Install MongoDB
Use local MongoDB or MongoDB Atlas cloud database.

### Step 3: Open the Project Folder
```bash
cd kishore-fullstack-portfolio
```

### Step 4: Install Dependencies
```bash
npm install
```

### Step 5: Create `.env` File
Create a file named `.env` and add:

```env
PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017/kishore_portfolio
ADMIN_KEY=12345
```

For MongoDB Atlas, replace `MONGO_URI` with your Atlas connection string.

### Step 6: Start the Server
```bash
npm start
```

Open browser:
```txt
http://localhost:5000
```

Admin page:
```txt
http://localhost:5000/admin.html
```

Default admin key:
```txt
12345
```

## API Endpoints

### Get Projects
```txt
GET /api/projects
```

### Add Project
```txt
POST /api/projects
```

### Delete Project
```txt
DELETE /api/projects/:id
```

### Send Contact Message
```txt
POST /api/contact
```

### View Contact Messages
```txt
GET /api/messages?adminKey=12345
```

## Deployment Steps

### Backend Deployment
Use Render:
1. Create a new Web Service.
2. Connect GitHub repository.
3. Add environment variables:
   - PORT
   - MONGO_URI
   - ADMIN_KEY
4. Start command:
```bash
npm start
```

### Database Deployment
Use MongoDB Atlas:
1. Create free cluster.
2. Create database user.
3. Allow network access.
4. Copy connection string.
5. Paste it in Render environment variables.

## Expected Outcome
This project gives practical experience in connecting frontend, backend and database. It also creates a live portfolio website useful for internships, placements and project demonstrations.

## Resume Line
Developed a full-stack personal portfolio website using HTML, CSS, JavaScript, Node.js, Express.js and MongoDB with dynamic project management, contact form and admin panel.
