const projectForm = document.getElementById("projectForm");
const adminStatus = document.getElementById("adminStatus");
const adminProjectList = document.getElementById("adminProjectList");
const messageForm = document.getElementById("messageForm");
const messageList = document.getElementById("messageList");

async function loadAdminProjects() {
  const response = await fetch("/api/projects");
  const projects = await response.json();

  adminProjectList.innerHTML = projects.map(project => `
    <div class="project-card">
      <h3>${project.title}</h3>
      <p>${project.description}</p>
      <p class="tech">${project.techStack}</p>
      <button class="delete-btn" onclick="deleteProject('${project._id}')">Delete</button>
    </div>
  `).join("");
}

projectForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  const data = {
    adminKey: document.getElementById("adminKey").value,
    title: document.getElementById("title").value,
    description: document.getElementById("description").value,
    techStack: document.getElementById("techStack").value,
    githubLink: document.getElementById("githubLink").value,
    liveLink: document.getElementById("liveLink").value
  };

  const response = await fetch("/api/projects", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(data)
  });

  const result = await response.json();
  adminStatus.textContent = result.message || "Project added successfully";

  if (response.ok) {
    projectForm.reset();
    loadAdminProjects();
  }
});

async function deleteProject(id) {
  const adminKey = prompt("Enter admin key:");

  const response = await fetch(`/api/projects/${id}`, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ adminKey })
  });

  const result = await response.json();
  alert(result.message);

  if (response.ok) {
    loadAdminProjects();
  }
}

messageForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  const adminKey = document.getElementById("messageAdminKey").value;

  const response = await fetch(`/api/messages?adminKey=${adminKey}`);
  const messages = await response.json();

  if (!response.ok) {
    messageList.innerHTML = `<p>${messages.message}</p>`;
    return;
  }

  messageList.innerHTML = messages.map(msg => `
    <div class="message-card">
      <h3>${msg.name}</h3>
      <p><b>Email:</b> ${msg.email}</p>
      <p>${msg.message}</p>
    </div>
  `).join("");
});

loadAdminProjects();
