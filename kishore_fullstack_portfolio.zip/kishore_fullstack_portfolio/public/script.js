const projectList = document.getElementById("projectList");
const contactForm = document.getElementById("contactForm");
const contactStatus = document.getElementById("contactStatus");

async function loadProjects() {
  try {
    const response = await fetch("/api/projects");
    const projects = await response.json();

    if (projects.length === 0) {
      projectList.innerHTML = `
        <div class="project-card">
          <h3>Personal Portfolio Website</h3>
          <p>Full-stack portfolio website with frontend, backend, database, admin panel and contact form.</p>
          <p class="tech">HTML, CSS, JavaScript, Node.js, Express.js, MongoDB</p>
        </div>
      `;
      return;
    }

    projectList.innerHTML = projects.map(project => `
      <div class="project-card">
        <h3>${project.title}</h3>
        <p>${project.description}</p>
        <p class="tech">${project.techStack}</p>
        ${project.githubLink ? `<a href="${project.githubLink}" target="_blank">GitHub</a>` : ""}
        ${project.liveLink ? `<a href="${project.liveLink}" target="_blank">Live Demo</a>` : ""}
      </div>
    `).join("");
  } catch (error) {
    projectList.innerHTML = "<p>Unable to load projects.</p>";
  }
}

contactForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  const data = {
    name: document.getElementById("name").value,
    email: document.getElementById("email").value,
    message: document.getElementById("message").value
  };

  try {
    const response = await fetch("/api/contact", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(data)
    });

    const result = await response.json();
    contactStatus.textContent = result.message;

    if (response.ok) {
      contactForm.reset();
    }
  } catch (error) {
    contactStatus.textContent = "Something went wrong.";
  }
});

loadProjects();
