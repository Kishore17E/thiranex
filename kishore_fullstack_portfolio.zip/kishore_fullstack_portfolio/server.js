const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
require("dotenv").config();

const Project = require("./models/Project");
const Message = require("./models/Message");

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.static("public"));

const PORT = process.env.PORT || 5000;
const MONGO_URI = process.env.MONGO_URI || "mongodb://127.0.0.1:27017/kishore_portfolio";
const ADMIN_KEY = process.env.ADMIN_KEY || "12345";

mongoose
  .connect(MONGO_URI)
  .then(() => console.log("MongoDB connected successfully"))
  .catch((error) => console.log("MongoDB connection error:", error.message));

app.get("/api/projects", async (req, res) => {
  try {
    const projects = await Project.find().sort({ createdAt: -1 });
    res.json(projects);
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch projects" });
  }
});

app.post("/api/projects", async (req, res) => {
  try {
    const { adminKey, title, description, techStack, githubLink, liveLink } = req.body;

    if (adminKey !== ADMIN_KEY) {
      return res.status(401).json({ message: "Invalid admin key" });
    }

    if (!title || !description || !techStack) {
      return res.status(400).json({ message: "Title, description and tech stack are required" });
    }

    const project = await Project.create({
      title,
      description,
      techStack,
      githubLink,
      liveLink
    });

    res.status(201).json(project);
  } catch (error) {
    res.status(500).json({ message: "Failed to add project" });
  }
});

app.delete("/api/projects/:id", async (req, res) => {
  try {
    const { adminKey } = req.body;

    if (adminKey !== ADMIN_KEY) {
      return res.status(401).json({ message: "Invalid admin key" });
    }

    await Project.findByIdAndDelete(req.params.id);
    res.json({ message: "Project deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: "Failed to delete project" });
  }
});

app.post("/api/contact", async (req, res) => {
  try {
    const { name, email, message } = req.body;

    if (!name || !email || !message) {
      return res.status(400).json({ message: "All fields are required" });
    }

    await Message.create({ name, email, message });
    res.status(201).json({ message: "Message sent successfully" });
  } catch (error) {
    res.status(500).json({ message: "Failed to send message" });
  }
});

app.get("/api/messages", async (req, res) => {
  try {
    const { adminKey } = req.query;

    if (adminKey !== ADMIN_KEY) {
      return res.status(401).json({ message: "Invalid admin key" });
    }

    const messages = await Message.find().sort({ createdAt: -1 });
    res.json(messages);
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch messages" });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
